# Step 66C — Storage privacy and signed-URL audit

Create:

- `ROMDOC/database/audits/45-storage-privacy-audit.sql`
- `ROMDOC/romdoc/scripts/audit-storage-security.cjs`
- `ROMDOC/STORAGE-PRIVACY-SIGNED-URL-CHECKLIST.md`

Run the SQL audit in Supabase SQL Editor one result set at a time.

Run the source audit from:

```bash
cd ROMDOC/romdoc
node scripts/audit-storage-security.cjs
```

The source script is heuristic. Every finding must be reviewed manually.

This step is read-only. Do not change storage policies or signed-URL routes until
the results have been reviewed for Step 66D remediation.
